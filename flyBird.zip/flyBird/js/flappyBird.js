$(document).ready(function(){
	var n = 0;
	var m = 0;
	var j = 0;
	var pipe_move = 0;
	var nm = 0;
	var time1 = null;
	var time2 = null;
	var time3 = null;
	var time4= null;
	var time5 = null;
	var time7 = null;

	$('.move_bird').hide();
	$('.num').hide();
	$('.end_page').hide();
	time1 = setInterval(function(){
		banner_move();
	},100);
	var random_num;
$('.start').click(function(){
	$(this).parent('.initial_page').hide();
	$('.move_bird').show();
	$('.num').show();
	start_click();
});

	function start_click(){
//柱子移动
		time4 = setInterval(function(){
			pipes_move();
		},80);
//随机生成柱子高度
		time2 = setInterval(function(){
			pipes_height();		
		},4600)

//小鸟鼠标事件
		var num = 1;
		function down(){
			if(num%2==0){
				$('.move_bird').css('background-image','url(img/down_bird1.png)');
			}else{
				$('.move_bird').css('background-image','url(img/down_bird0.png)');
			}
			$('.move_bird').animate({'top':'+=20px'},100);
		}
		function up(){
			if(num%2==0){
				$('.move_bird').css('background-image','url(img/up_bird1.png)');
			}else{
				$('.move_bird').css('background-image','url(img/up_bird0.png)');
			}
			$('.move_bird').animate({'top':'-=20px'},100);
			num++;
		}

	//自由下落
	 	time5= setInterval(function(){
				down();
			}
		,100);	

	//鼠标松开自由下落
		$('.container').mouseup(function(){
			time5= setInterval(function(){
				down();
			}
			,100);	
		})

	//鼠标按下上升
		$('.container').mousedown(function(){
			clearInterval(time5);
			up();
		})	
		var bird_height = parseInt($('.move_bird').css('top'));
		time7 = setInterval(function(){
			crash();
		},100)
	}
//开始页面 
	var k = 1;
	time3 = setInterval(function(){
		initial_act();
	},300);


//小鸟碰到柱子
	function crash(){
		var bird_height = parseInt($('.move_bird').css('top'));
		var up_height1 = parseInt($('.up_pipe1').css('height'));
		// alert(up_height1);
		var up_height2 = parseInt($('.up_pipe2').css('height'));
		var down_height1 = parseInt($('.down_pipe1').css('height'));
		var down_height2 = parseInt($('.down_pipe2').css('height'));
		var cha = 370-bird_height;
		var down1 = 395-down_height1;
		var down2 = 395-down_height2;
		// alert(pipe_move);
		if(-67<pipe_move&&pipe_move<33||(-707)>pipe_move&&pipe_move>(-827)){
			// alert(pipe_move);
			if(up_height1<bird_height&&bird_height<down1){
				if(pipe_move==(-57)||pipe_move ==(-807)){
					nm++;
					// alert('nm++');
					$('.num').html(nm);
				}
			}else{
				end();
			}
		}
		if(pipe_move<(-217)&&pipe_move>(-317)||pipe_move<(-417)&&pipe_move>(-527)){
			if(up_height2<bird_height&&bird_height<down2){
				if(pipe_move==(-307)||pipe_move==(-507)){
					nm++;
					$('.num').html(nm);
				}
			}else{
				end();
			}
		}
		if(bird_height>380){
			end();
		}
	}

//线条移动 
	function banner_move(){
		n-=10;
		$('.banner').css('margin-left',n+'px');
		var left = parseInt($('.banner').css('margin-left'));
		if(left<(-343)){
			n=0;
			$('.banner li:eq(0)').appendTo('.banner');
			$('.banner').css('margin-left',0);
		}
	}

//柱子移动
	function pipes_move(){
		m=m-10;
		pipe_move = m+343;
		$('.pipe').css('margin-left',pipe_move+'px');
		if(pipe_move<-830){
			m=0;
			$('.pipe li:eq(0)').appendTo('pipe');
			$('.pipe').css('margin-left','343px');
		}
	}
// 随机生成柱子高度
	function pipes_height(){
		random_num = Math.random();
		if(0.1<random_num<0.2){
			num = random_num*1300;
		}else if(0.2<random_num<0.4){
			num = random_num*350
		}else if(0.4<random_num<0.5){
			num = random_num*280;
		}else if(0.5<random_num<0.8){
			num = random_num*220
		}else{
			num = random_num*150;
		}
		   down_height = 280-num;
		if(j%2==0){
			$('.up_pipe1').css('height',num+'px');
			$('.down_pipe1').css('height',down_height+'px');
			$('.up_pipe4').css('height',num+'px');
			$('.down_pipe4').css('height',down_height+'px');
		}else{
			$('.up_pipe2').css('height',num+'px');
			$('.down_pipe2').css('height',down_height+'px');
			$('.up_pipe3').css('height',num+'px');
			$('.down_pipe3').css('height',down_height+'px');
			}	
		j++;
	}
//开始页面
	function initial_act(){
		if(k%2==0){
			$('.bird').css('background-image','url(img/bird0.png)');
			$('.open').css('margin-top','65px');
		}else{
			$('.bird').css('background-image','url(img/bird1.png)');
			$('.open').css('margin-top','55px');
		}
		k++;
	}

//结束
	function end(){
		$('.initial_page').hide();
		$('.end_page').show();
		clearInterval(time1);
		clearInterval(time2);
		// clearInterval(time3);
		clearInterval(time4);
		clearInterval(time5);
		clearInterval(time7);
		$('.move_bird').css('top','380px');
		$('.scroll').html(nm);
	}

//重新开始
	$('.ok').click(function(){
		window.location.reload();
	});
});